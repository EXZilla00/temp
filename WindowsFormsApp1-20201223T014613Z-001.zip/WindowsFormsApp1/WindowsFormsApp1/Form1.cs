﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string fileName = DateTime.Now.Year.ToString() + "_"
               + DateTime.Now.Month.ToString() + "_"
               + DateTime.Now.Day.ToString() + "_"
               + DateTime.Now.Hour.ToString() + "_"
               + DateTime.Now.Minute.ToString() + "_"
               + DateTime.Now.Second.ToString() + ".txt";
            saveFileDialog1.FileName = fileName;
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string txtLine = textBox1.Text;
                StreamWriter sw = new StreamWriter(saveFileDialog1.FileName);
                sw.WriteLine(txtLine);
                sw.Flush();
                sw.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string txtLine = "";
                StreamReader sr = new StreamReader(openFileDialog1.FileName);
                while (sr.Peek() != -1)
                {
                    txtLine += sr.ReadLine() + "\r\n"; ;
                }
                sr.Close();
                textBox1.Text = txtLine;
            }
        }

        bool serialFlag;
        private void button3_Click(object sender, EventArgs e)
        {
            if (serialFlag == true)
            {
                button3.Text = "COM ON";
                serialFlag = false;
                timer1.Enabled = false;
                serialPort1.Close();
            }
            else
            {
                button3.Text = "COM OFF";
                serialFlag = true;
                serialPort1.Open();
                serialPort1.DiscardInBuffer();
                timer1.Enabled = true;
            }
        }

        string InString = "";
        double read = 0;
        double put1 = 0;
        double put2 = 0;
        double sum1 = 0;
        double sum2 = 0;
        double f = 0;
        int time = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {        
            string start1 = "";
            string start2 = "";
            try
            {
                serialPort1.ReadTimeout = 1000;
                InString = serialPort1.ReadExisting();
                if (InString.Length == 0)
                {
                    return;
                }
                else
                {
                    start1 = DateTime.Now.Year.ToString() + "/"         //歷史紀錄
                    + DateTime.Now.Month.ToString() + "/"
                    + DateTime.Now.Day.ToString() + "/"
                    + DateTime.Now.Hour.ToString() + ":"
                    + DateTime.Now.Minute.ToString() + ":"
                    + DateTime.Now.Second.ToString() + "\r\n";
                    textBox1.Text += start1 + InString + "\r\n";             
                    textBox2.Text = "";
                    textBox2.Text = InString;                           //目前溫度
                    start2 = DateTime.Now.ToString();                   
                    textBox3.Text = start2;                             //目前時間
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex.ToString(), "錯誤通知");
            }
            //
            if (radioButton1.Checked == true)                           //最高最低溫度
            {
                if (read < double.Parse(InString))
                {
                    read = double.Parse(InString);
                    if (put1 < read)
                    {
                        put1 = read;        
                    }                                                       
                }
                textBox4.Text = Convert.ToString(put1);
                if (read > double.Parse(InString))
                {
                    read = double.Parse(InString);
                    put2 = read;
                }
            }
            if (radioButton2.Checked == true)
            {
                if (read > double.Parse(InString))
                {
                    read = double.Parse(InString);
                    if (put2 > read)
                    {
                        put2 = read;
                    }
                } 
                textBox4.Text = Convert.ToString(put2);
                if (read < double.Parse(InString))
                {
                    read = double.Parse(InString);
                    put1 = read;
                }
            }
            //
            textBox5.Text = Convert.ToString(Math.Round(put1-put2, 2));     //高低溫度差
            //
            time++;
            sum1 += double.Parse(InString);
            sum2 = sum1 / time;
            textBox6.Text = Convert.ToString(Math.Round(sum2, 2));          //平均溫度
            //
            f = double.Parse(InString) * (9.0 / 5.0) + 32;                  //華氏溫度
            textBox7.Text = Convert.ToString(f);
            //
            if (double.Parse(InString) > 24)                                //目前舒適度
            {
                textBox8.Text = "\r\n悶熱";
                textBox8.BackColor = System.Drawing.Color.Red;
            }
            else if ((double.Parse(InString) <= 24) && (double.Parse(InString) >= 18))
            {
                textBox8.Text = "\r\n舒適";
                textBox8.BackColor = System.Drawing.Color.Lime;
            }
            else if (18 > double.Parse(InString))
            {
                textBox8.Text = "\r\n寒冷";
                textBox8.BackColor = System.Drawing.Color.Blue;
            }          
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)     //改變視窗顏色
        {
            if (comboBox1.SelectedIndex == 0)
            {
                this.BackColor = System.Drawing.Color.White;
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                this.BackColor = System.Drawing.Color.Red;
            }
            else if (comboBox1.SelectedIndex == 2)
            {
                this.BackColor = System.Drawing.Color.Orange;
            }
            else if (comboBox1.SelectedIndex == 3)
            {
                this.BackColor = System.Drawing.Color.Gold;
            }
            else if (comboBox1.SelectedIndex == 4)
            {
                this.BackColor = System.Drawing.Color.Green;
            }
            else if (comboBox1.SelectedIndex == 5)
            {
                this.BackColor = System.Drawing.Color.Blue;
            }
            else if (comboBox1.SelectedIndex == 6)
            {
                this.BackColor = System.Drawing.Color.Magenta;
            }
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.SelectionStart = textBox1.Text.Length;
            textBox1.ScrollToCaret();
        }
        private void Button6_Click(object sender, EventArgs e)          //定義說明
        {
            MessageBox.Show("夏季舒適溫度：19—24℃\r\n冬季舒適溫度：17—22℃", "舒適溫度定義說明", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            Application.Restart();                                      //重新讀取
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }
        private void GroupBox2_Enter(object sender, EventArgs e)
        {

        }
        private void TextBox2_TextChanged(object sender, EventArgs e)
        {
            
        }
        private void TextBox3_TextChanged_1(object sender, EventArgs e)
        {
            
        } 
        private void Form1_Load(object sender, EventArgs e)
        {
        }
        private void TextBox4_TextChanged(object sender, EventArgs e)
        {

        }
        private void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {           
        }
        private void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void TextBox5_TextChanged(object sender, EventArgs e)
        {

        }
        private void TextBox4_TextChanged_1(object sender, EventArgs e)
        {

        }
        private void TextBox6_TextChanged(object sender, EventArgs e)
        {

        }
        private void GroupBox6_Enter(object sender, EventArgs e)
        {

        }
        private void TextBox10_TextChanged(object sender, EventArgs e)
        {

        }
        private void GroupBox7_Enter(object sender, EventArgs e)
        {

        }
        private void TextBox7_TextChanged(object sender, EventArgs e)
        {

        }
        private void RadioButton1_CheckedChanged_1(object sender, EventArgs e)
        {
           
        }
        private void TextBox6_TextChanged_1(object sender, EventArgs e)
        {

        }
        private void TextBox7_TextChanged_1(object sender, EventArgs e)
        {

        }
        private void TextBox8_TextChanged(object sender, EventArgs e)
        {

        }
        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
        }
        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }
    }
}
